import torch
import torch.nn as nn
from model import common
from model import DEARNet


class CoreModule(nn.Module):
    def __init__(self, features, M, r, L=32):
        '''
        features: 特征图的通道数
        M: Gated Convolutional分支数量
        G: Gated Convolutional分支的组数
        r: SE特征压缩比例。
        stride: 卷积层的步长，默认为1.
        L: SE模块中线形成的最小通道数，默认为32
        '''
        super(CoreModule, self).__init__()
        # 计算SE模块中线性层的输出通道数d，其值为features / r 和 L 中的较大者，并将 M 和 features 分别赋值给 self.M 和 self.features。
        d = max(int(features / r), L)
        self.M = M
        self.features = features

        # 创建一个空的模块列表 edgeconvs ，用于存放边缘卷积模块。
        self.edgeconvs = nn.ModuleList([])
        # 创建了一个无批量归一化的残差块 recon_trunk，其输入通道数为features，激活函数为PReLU。
        self.recon_trunk = common.ResidualBlock_noBN(nf=features, at='relu')
        # 接下来创建了一个 3 * 3 的卷积层，输入和输出通道数都为features，填充大小为1
        self.conv3x3 = nn.Conv2d(features, features, kernel_size=3, padding=1)
        # 然后定义了三个不同类型的边缘卷积组合，分别为 sobelx、sobely、laplacian卷积核
        EC_combination = ['conv1-sobelx', 'conv1-sobelxy', 'conv1-sobely', 'conv1-sobelyx', 'conv1-laplacian']
        # 并通过循环在模块列表 edgeconvs 中添加这些组合形成的边缘卷积模块。
        for i in range(len(EC_combination)):
            self.edgeconvs.append(nn.Sequential(
                common.EdgeConv(EC_combination[i], features, features),
            ))

        # 创建了一个 1*1 的卷积层 conv_reduce，输入通道数为边缘卷积模块的数量乘以 features，用于将不同类型的边缘特征进行融合。
        self.conv_reduce = nn.Conv2d(features * len(EC_combination), features, kernel_size=1, padding=0)
        # 然后创建了一个空间注意力机制模块 sa，用于提取最重要的特征。
        self.sa = DEARNet.SpatialAttention()
        # 接着创建了一个全连接层 fc，输入特征数 features，输出特征数为 d，用于将输入特征进行压缩。
        self.fc = nn.Linear(features, d)
        # 然后创建了 M 个全连接层 fcs
        self.fcs = nn.ModuleList([])
        for i in range(M):
            # 每个全连接层的输入特征数为 d，输出特征数为features，用于生成 M 个 Gated Convolutional 分支的权重。
            self.fcs.append(
                nn.Linear(d, features)
            )
        # 最后创建了一个Softmax激活函数，用于对 M 个 Gated Convolutional分支的权重进行归一化。
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x):
        '''
        前向传播方法
        x: 接受的一个输入张量
        '''
        # based_x变量用于保存输入张量，后续用于残差连接
        based_x = x
        # 通过调用残差块recon_trunk处理输入张量based_x，将处理结果保存在out变量中。
        out = self.recon_trunk(based_x)

        # 对于每个边缘卷积模块 edgeconv ，通过将输入张量 x 输入到模块中得到特征张量 fea
        for i, edgeconv in enumerate(self.edgeconvs):
            fea = edgeconv(x)
            if i == 0:
                # 将第一个特征张量赋值给 feas
                feas = fea
            else:
                # 对于其他特征张量，则使用 cat 在通道维度上进行拼接，最终得到合并的特征张量 feas
                feas = torch.cat([feas, fea], dim=1)
        # 将合并的特征张量feas通过 1 * 1 ，的卷积层conv_reduce进行通道数的压缩
        feas = self.conv_reduce(feas)
        # 将压缩后的特征张量feas输入到空间注意力模块 sa 中，对特征张量进行加权，最后将加权后的结果与原始特征张量相乘。
        feas = self.sa(feas) * feas

        # 使用torch.cat将输入特征out和加权后的特征feas在通道维度上进行拼接，并通过torch.sum对拼接后的特征张量在通道维度上求和得到fea_f_u。
        feas_f = torch.cat([out.unsqueeze_(dim=1), feas.unsqueeze_(dim=1)], dim=1)
        fea_f_U = torch.sum(feas_f, dim=1)

        # 对于 fea_f_U，先通过 mean 函数在最后两个维度上求平均值，得到fea_f_s。
        fea_f_s = fea_f_U.mean(-1).mean(-1)
        # 将fea_f_s输入到全连接层 fc 中得到  fea_f_z。
        fea_f_z = self.fc(fea_f_s)
        # 对于每个全连接层 fc ，将 fea_f_z 输入到全连接层中得到 vector_f，并在通道维度上进行拼接，得到attention_vectors_f
        for i, fc in enumerate(self.fcs):
            vector_f = fc(fea_f_z).unsqueeze_(dim=1)
            if i == 0:
                # 将第一个特征向量赋值给 attention_vectors_f 张量。
                attention_vectors_f = vector_f
            else:
                # 其他非第一个特征向量将attention_vectors_f和vector_f进行按维度1拼接得到attention_vectors_f
                attention_vectors_f = torch.cat([attention_vectors_f, vector_f], dim=1)
        # 通过softmax函数对 attention_vectors_f 进行归一化
        attention_vectors_f = self.softmax(attention_vectors_f)
        # 然后对结果进行维度扩展，增加两个维度
        attention_vectors_f = attention_vectors_f.unsqueeze(-1).unsqueeze(-1)
        # 将加权后的特征张量feas_f与注意力向量 attention_vectors_f相乘，并在通道维度上求和得到最终输出的特征张量 fea_v_out。
        fea_v_out = (feas_f * attention_vectors_f).sum(dim=1)
        # 最后返回fea_v_out。
        return fea_v_out


# # Edge-guided Residual Attention Block (EGRAB)
# 一个名为EGRAB的PyTorch模型，其中包括一个核心子模块 CoreModule和一个简单的残差块
class EGRAB(nn.Module):
    def __init__(self, conv, n_feat, flag, bias=True, bn=False, act=nn.PReLU()):
        '''
            conv: 卷积层类别，如nn.Conv2d
            n_feat: 输入特征的通道数
            kernel_size: 卷积核大小
            reduction: 降维倍率，用于将特征映射降维
            bias: 是否使用偏置项
            bn: 是否使用批归一化
            act: 激活函数k,mk残差块的贡献大小
        '''
        # 首先调用父类的构造函数，初始化神经网络模型。
        super(EGRAB, self).__init__()
        self.n_feat = n_feat
        # 定义的RB模块
        modules_body = []
        # 定义一个包含两个卷积层、可选的批归一化层和激活函数的模块集合。
        for i in range(2):
            # modules_body.append(conv(n_feat, n_feat, kernel_size, bias=bias))
            modules_body.append(conv)
            if bn:
                modules_body.append(nn.BatchNorm2d(n_feat))
            if i == 0:
                modules_body.append(act)
        # 将核心子模块 CoreModule 添加到模块集合中，
        # 它使用了 n_feat 个通道，M=2 表示分组卷积层的数量，G=8 表示组数，r=2 表示每个组内的通道降维数量，stride=1 表示卷积层的步长，L=32表示残差块中卷积层的通道数。
        modules_body.append(CoreModule(n_feat, M=2, r=2, L=32))
        # 将所有模块封装成顺序神经网络，并将复原比例因子保存在对象中
        self.body = nn.Sequential(*modules_body)
        self.conv1 = nn.Conv2d(self.n_feat, self.n_feat, 1, bias=False)
        self.conv1_re = nn.Conv2d(64, self.n_feat, 1, bias=False)
        # self.conv3x3_br = nn.Sequential(
        #     nn.Conv2d(n_feat, n_feat, 1, 1),
        #     # nn.BatchNorm2d(n_feat),
        #     nn.ReLU(),
        #     # nn.Conv2d(n_feat, n_feat, 3, 1, 1),
        #     # nn.BatchNorm2d(n_feat),
        #     # nn.ReLU(),
        # )

    # 前向传播，对输入特征x执行顺序神经网络运算，得到残差块输出，最后将残差块输出与输入特征相加，并返回结果。
    def forward(self, x):
        res = self.body(x)
        return res
