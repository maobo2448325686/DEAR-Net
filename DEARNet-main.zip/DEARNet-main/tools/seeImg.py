# -*- coding: UTF-8 -*-
"""
@file    : seeImg.py
@time    : 2023/10/24 0024 9:06
@IDE     : Pycharm
@Python  : 3.11.3
@author  : KENOPSIAN
"""
import cv2

image_path = "../data/levir_CD/train/images/t1/train_1.png"
image = cv2.imread(image_path)
height, width, channels = image.shape
print("图像宽度：", width)
print("图像高度：", height)
