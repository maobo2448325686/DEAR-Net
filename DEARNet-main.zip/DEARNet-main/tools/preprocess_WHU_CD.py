import os
import random
import shutil
from PIL import Image

# 下面代码表示切割数据
# Image.MAX_IMAGE_PIXELS = None
#
# input_file = r'D:\DataSoftWare\maobo\Pycharm\GAS-Net-main-new\data\WHU_CD\change label\change_label.png'
# output_directory = r'D:\DataSoftWare\maobo\Pycharm\GAS-Net-main-new\data\WHU_CD\change label\label'  # 输出目录路径
# tile_size = 256  # 小图的尺寸
#
# # 打开大图
# image = Image.open(input_file)
#
# # 计算水平和垂直方向上的小图数量
# num_tiles_horizontal = image.width // tile_size
# num_tiles_vertical = image.height // tile_size
#
# # 循环裁剪并保存小图
# for y in range(num_tiles_vertical):
#     for x in range(num_tiles_horizontal):
#         left = x * tile_size
#         upper = y * tile_size
#         right = left + tile_size
#         lower = upper + tile_size
#         tile = image.crop((left, upper, right, lower))
#         tile_filename = f"tile_{x}_{y}.png"  # 生成小图的文件名
#         tile.save(f"{output_directory}/{tile_filename}")

#######################################################################################################################


# 以下代码表示随机分配
# input_folder = r'D:\DataSoftWare\maobo\Pycharm\GAS-Net-main-new\data\WHU_CD\before\t1'  # 输入文件夹路径
# output_folder1 = r'D:\DataSoftWare\maobo\Pycharm\GAS-Net-main-new\data\WHU_CD\train\images\t1'   # 输出文件夹1路径
# output_folder2 = r'D:\DataSoftWare\maobo\Pycharm\GAS-Net-main-new\data\WHU_CD\val\images\t1'  # 输出文件夹2路径
# output_folder3 = r'D:\DataSoftWare\maobo\Pycharm\GAS-Net-main-new\data\WHU_CD\test\images\t1'  # 输出文件夹3路径
# ratio = [6, 2, 2]  # 分配比例
#
# # 获取文件夹中所有图片文件的路径
# image_files = [os.path.join(input_folder, file) for file in os.listdir(input_folder) if file.endswith(".png")]
#
# # 获取图片总数
# total_images = len(image_files)
#
# # 计算每个文件夹应该保存的图片数量
# num_images = [total_images * r // sum(ratio) for r in ratio]
#
# # 将文件夹中的图片随机排序
# random.shuffle(image_files)
#
# # 分配图片到各个文件夹
# for i, folder in enumerate([output_folder1, output_folder2, output_folder3]):
#     current_images = image_files[:num_images[i]]
#     for image in current_images:
#         shutil.move(image, folder)
#     image_files = image_files[num_images[i]:]

##################################################################################################################


# 按需分配
source_folder = r'D:\DataSoftWare\maobo\Pycharm\GAS-Net-main-new\data\WHU_CD\change label\label'  # 源文件夹路径
reference_folder = r'D:\DataSoftWare\maobo\Pycharm\GAS-Net-main-new\data\WHU_CD\val\images\t1'  # 参考文件夹路径
output_folder = r'D:\DataSoftWare\maobo\Pycharm\GAS-Net-main-new\data\WHU_CD\val\label'  # 输出文件夹路径

# 获取参考文件夹中的所有图片文件名
reference_files = [os.path.splitext(file)[0] for file in os.listdir(reference_folder) if file.endswith(".png")]

# 遍历源文件夹中的所有文件
for file in os.listdir(source_folder):
    if file.endswith(".png"):
        filename = os.path.splitext(file)[0]
        if filename in reference_files:
            # 如果文件名在参考文件夹中存在，则移动文件到输出文件夹
            source_file_path = os.path.join(source_folder, file)
            output_file_path = os.path.join(output_folder, file)
            shutil.move(source_file_path, output_file_path)