import math

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init
from torch.autograd import Variable


# 该函数用于创建一个标准的2D卷积层(nn.Conv2d)，，快速创建一个具有常用设置（如same padding）的2D卷积层对象
def default_conv(in_channels, out_channels, kernel_size, bias=True):
    # in_channels 输入通道数
    # out_channels 输出通道数
    # kernel_size 卷积核大小
    # bias 是否使用偏置项

    # 函数体内部创建了一个卷积层实例nn.Cov2d并将其返回
    return nn.Conv2d(
        # 参数如下：
        # in_channels：输入通道数
        # out_channels：输出通道数
        # kernel_size：卷积核大小
        in_channels, out_channels, kernel_size,
        # padding：表示采用的是same padding （填充输入使得输出尺寸与输入相同）
        # bias：参数用于控制是否使用偏置项，默认为True
        padding=(kernel_size // 2), bias=bias)


# 定义了一个名为MeanShift的类，继承自nn.Conv2d类，并添加了一些自定义的逻辑。
class MeanShift(nn.Conv2d):
    # 四个参数，rgb_range：RGB值的范围；rgb_mean：RGB通道的均值；rgb_std：RGB通道的标准差；sign：操作的符号
    def __init__(self, rgb_range, rgb_mean, rgb_std, sign=-1):
        # 首先调用父类nn.Conv2d的构造函数，并传入参数3，3，kernel_size=1，创建一个3x3的卷积层。
        # MeanShift类的目的不是作为卷积层使用吗，而是利用卷积层的权重和偏置来实现平移和缩放操作。
        super(MeanShift, self).__init__(3, 3, kernel_size=1)
        # 将rgb_std转换为张量类型，并赋值给变量std，然后权重矩阵self.weight.data设置为单位矩阵，并通过除以std.view(3,1,1,1)来进行缩放操作。
        # 目的是将输入数据按照RGB通道的标准差进行缩放。
        std = torch.Tensor(rgb_std)
        self.weight.data = torch.eye(3).view(3, 3, 1, 1)
        self.weight.data.div_(std.view(3, 1, 1, 1))
        # 将偏置项self.bias.data设置为sign * rgb_range * torch.Tensor(rgb_mean)，其中rgb_range表示RGB值的范围，rgb_mean表示RGB通道的均值。
        # 然后，再次通过除以std来对偏置项进行缩放处理，与权重矩阵相对应。
        self.bias.data = sign * rgb_range * torch.Tensor(rgb_mean)
        self.bias.data.div_(std)
        # 将requires_grad设置为false，表示该层的参数不需要计算梯度，即固定不变
        self.requires_grad = False


# BasicBlock类封装了一种基本的卷积块结构，该结构由一个卷积层、一个可选的批归一化层和一个可选的激活函数组成。这个类的实例可以被用来构建卷积神经网络的基本模块。
class BasicBlock(nn.Sequential):
    # 构造函数接受多个参数：
    # in_channels：输入通道数
    # out_channels：输出通道数
    # kernel_size：卷积核大小
    # stride：步长，默认为1
    # bias：是否包含偏置项
    # bn：是否使用批归一化，默认为True
    # act：激活函数，默认为ReLU函数
    def __init__(
            self, in_channels, out_channels, kernel_size, stride=1, bias=False,
            bn=True, act=nn.ReLU(True)):

        # 首先定义一个列表m，用于存储nn.Sequential中的子模块
        m = [
            # 将一个nn.Conv2d模块添加到列表m中，该卷积模块的输入通道数为in_channels，输出通道数为out_channels，卷积核大小为kernel_size，通过设置padding来保持输入和输出的宽高一致，步长为stride，是否包含偏执项由bias决定。
            nn.Conv2d(in_channels, out_channels, kernel_size, padding=(kernel_size // 2), stride=stride, bias=bias)
        ]
        if bn:
            # 则在列表中添加一个nn.BatchNorm2d模块，其输入通道数为out_channels，用于批归一化操作。
            m.append(nn.BatchNorm2d(out_channels))
        if act is not None:
            # 如果act不为None，则将act设置为nn.PReLU(num_parameters=out_channels)，即带参数的PReLU激活函数，并将其添加到列表m中。
            act = nn.PReLU(num_parameters=out_channels)
            m.append(act)
        # 调用父类nn.Sequential的构造函数，传入列表m作为参数，完成BasicBlock类的初始化
        super(BasicBlock, self).__init__(*m)

# Upsampler类用于定义上采样模块，根据输入的上采样倍数和特征通道数，自动选择合适的操作来实现上采样。
# 可以通过设置bn和act参数来决定是否使用批归一化和激活函数。
# 这个类的实例可以被用来构建图像超分辨率等需要进行上采样的模型。
class Upsampler(nn.Sequential):
    # 初始化接受多个参数，
    # conv 表示卷积函数
    # scale 表示上采样倍数
    # n_feat 表示特征通道数
    # bn 表示是否使用批归一化，默认为False
    # act 表示是否使用激活函数，默认为False
    # bias表示是否包含偏置项，默认为True。
    def __init__(self, conv, scale, n_feat, bn=False, act=False, bias=True):
        # 创建一个m列表，用于存储序列的子模块
        m = []
        # 如果scale是2的幂次方（即判断(scale & (scale - 1)) == 0 为真）
        if (scale & (scale - 1)) == 0:  # Is scale = 2^n?
            # 循环range(int(math.log(scale, 2)))次，
            for _ in range(int(math.log(scale, 2))):
                # 即将输入通道数为n_feat，输出通道数为4 * n_feat，卷积核大小为3的卷积层添加到列表中
                m.append(conv(n_feat, 4 * n_feat, 3, bias))
                # 用于执行像素重排操作，将图像的通道数减少为原来的1/4
                m.append(nn.PixelShuffle(2))
                if bn:
                    # 将nn.BatchNorm2d(n_feat)添加到列表m中，用于执行批归一化操作。
                    m.append(nn.BatchNorm2d(n_feat))
                if act:
                    # 则将一个激活函数添加到列表m中
                    m.append(act())
        # 如果scale等于3，则执行以下操作：
        elif scale == 3:
            # 将conv(n_feat, 9 * n_feat, 3, bias)添加到列表m中，即将输入通道数为n_feat，输出通道数为9 * n_feat，卷积核大小为3的卷积层添加到列表中。
            m.append(conv(n_feat, 9 * n_feat, 3, bias))
            # 将 nn.PixelShuffle(3) 添加到列表m中，用于执行像素重排操作，将图像的通道数减少为原来的1/9.
            m.append(nn.PixelShuffle(3))
            if bn:
                # 批归一化
                m.append(nn.BatchNorm2d(n_feat))
            if act:
                # 激活函数
                m.append(act())
        else:
            # 如果scale既不是2的幂次方，也不等于3，则抛出一个NotImplementedError异常
            raise NotImplementedError
        # 最后调用父类nn.Sequential的构造函数，传入列表m作为参数，完成Upsampler类的初始化。
        super(Upsampler, self).__init__(*m)

# 一个自定义卷积层EdgeConv，该层实现了三种不同种类的边缘卷积操作：sobel_x，sobel_y和拉普拉斯卷积
class EdgeConv(nn.Module):
    # conv_edge 用于指定使用哪一种边缘卷积方式，可以选择下面的判断之一。
    # in_channels和out_channels分别表示输入和输出的通道数。
    def __init__(self, conv_edge, in_channels, out_channels):
        # 调用父类的构造函数，初始化父类相关的属性。
        super(EdgeConv, self).__init__()

        # 保存传入的参数conv_edge、in_channels和out_channels为对象的属性。
        self.conv_edge = conv_edge
        self.in_channels = in_channels
        self.out_channels = out_channels

        # 如果conv_edge参数为‘conv-sobelx'，则使用一维sobel算子对输入数据进行卷积。
        if self.conv_edge == 'conv1-sobelx':
            # 顶一个二维卷积操作，其中in_channels和out_channels分别为输入和输出的通道数，卷积核为1，填补为0
            conv0 = torch.nn.Conv2d(self.in_channels, self.out_channels, kernel_size=1, padding=0)
            # 将conv0.weight和conv0.bias分别保存为对象的属性k0和b0，后续用于计算卷积操作
            self.k0 = conv0.weight
            self.b0 = conv0.bias
            # init scale & bias
            # 初始化scale张量和bias张量，它们被定义为nn.Parameter类型，可以被优化的参数
            scale = torch.randn(size=(self.out_channels, 1, 1, 1)) * 1e-3   # 使用Pytorch的随机数生成函数torch.randn()生成了一个大小为(self.out_channels, 1, 1, 1)的张量，
                                                                            # 其中self.out_channels表示输出通道数，这个张量中的元素值是从标准正态分布N（0, 1）中随机生成的
                                                                            # 1e-3 这个数值通常被称为”缩放因子“，用于调整张量中元素的范围和大小。
            self.scale = nn.Parameter(torch.FloatTensor(scale))    # 保存到EdgeConv层的scale属性中供后续调用，这样做的目的是为了让模型在训练过程中对这些参数进行优化，从而提高模型的性能
            # bias同scale一样
            bias = torch.randn(self.out_channels) * 1e-3
            bias = torch.reshape(torch.FloatTensor(bias), (self.out_channels,))
            self.bias = nn.Parameter(bias)
            # init template
            # 创建一个大小为(out_channels, 1, 3, 3)的零张量template，其中输出通道数为out_channels，输入通道数为1，模板的高度和宽度为3，用于存储sobel算子的权重。
            self.template = torch.zeros((self.out_channels, 1, 3, 3), dtype=torch.float32)
            for i in range(self.out_channels):
                self.template[i, 0, 0, 0] = -1.0     # 表示第i个通道的模板的左上角元素为1.0
                self.template[i, 0, 1, 0] = -2.0     # 表示第i个通道的模板的中间上方元素为2.0
                self.template[i, 0, 2, 0] = -1.0     # 表示第i个通道的模板的右上角元素为1.0
                self.template[i, 0, 0, 2] = 1.0    # 表示第i个通道的模板的左上角元素为-1.0
                self.template[i, 0, 1, 2] = 2.0    # 表示第i个通道的模板的的中间下方元素为-2.0
                self.template[i, 0, 2, 2] = 1.0    # 表示第i个通道的模板的右下角元素为-1.0
            # 将template张量转换为nn.parameter类型，同时设置requires_grad=False，表示template不参与模型训练过程中的梯度反向传播。
            self.template = nn.Parameter(data=self.template, requires_grad=False)

        elif self.conv_edge == 'conv1-sobelxy':
            conv0 = torch.nn.Conv2d(self.in_channels, self.out_channels, kernel_size=1, padding=0)
            self.k0 = conv0.weight
            self.b0 = conv0.bias
            # init scale & bias
            scale = torch.randn(size=(self.out_channels, 1, 1, 1)) * 1e-3
            self.scale = nn.Parameter(torch.FloatTensor(scale))
            bias = torch.randn(self.out_channels) * 1e-3
            bias = torch.reshape(torch.FloatTensor(bias), (self.out_channels,))
            self.bias = nn.Parameter(bias)
            # init template
            self.template = torch.zeros((self.out_channels, 1, 3, 3), dtype=torch.float32)
            for i in range(self.out_channels):
                self.template[i, 0, 0, 0] = -2.0
                self.template[i, 0, 0, 1] = -1.0
                self.template[i, 0, 1, 0] = -1.0
                self.template[i, 0, 1, 2] = 1.0
                self.template[i, 0, 2, 1] = 1.0
                self.template[i, 0, 2, 2] = 2.0
            self.template = nn.Parameter(data=self.template, requires_grad=False)

        elif self.conv_edge == 'conv1-sobely':
            conv0 = torch.nn.Conv2d(self.in_channels, self.out_channels, kernel_size=1, padding=0)
            self.k0 = conv0.weight
            self.b0 = conv0.bias
            # init scale & bias
            scale = torch.randn(size=(self.out_channels, 1, 1, 1)) * 1e-3
            self.scale = nn.Parameter(torch.FloatTensor(scale))
            bias = torch.randn(self.out_channels) * 1e-3
            bias = torch.reshape(torch.FloatTensor(bias), (self.out_channels,))
            self.bias = nn.Parameter(bias)
            # init template
            self.template = torch.zeros((self.out_channels, 1, 3, 3), dtype=torch.float32)
            for i in range(self.out_channels):
                self.template[i, 0, 0, 0] = -1.0
                self.template[i, 0, 0, 1] = -2.0
                self.template[i, 0, 0, 2] = -1.0
                self.template[i, 0, 2, 0] = 1.0
                self.template[i, 0, 2, 1] = 2.0
                self.template[i, 0, 2, 2] = 1.0
            self.template = nn.Parameter(data=self.template, requires_grad=False)

        elif self.conv_edge == 'conv1-sobelyx':
            conv0 = torch.nn.Conv2d(self.in_channels, self.out_channels, kernel_size=1, padding=0)
            self.k0 = conv0.weight
            self.b0 = conv0.bias
            # init scale & bias
            scale = torch.randn(size=(self.out_channels, 1, 1, 1)) * 1e-3
            self.scale = nn.Parameter(torch.FloatTensor(scale))
            bias = torch.randn(self.out_channels) * 1e-3
            bias = torch.reshape(torch.FloatTensor(bias), (self.out_channels,))
            self.bias = nn.Parameter(bias)
            # init template
            self.template = torch.zeros((self.out_channels, 1, 3, 3), dtype=torch.float32)
            for i in range(self.out_channels):
                self.template[i, 0, 0, 1] = -1.0
                self.template[i, 0, 0, 2] = -2.0
                self.template[i, 0, 1, 0] = 1.0
                self.template[i, 0, 1, 2] = -1.0
                self.template[i, 0, 2, 0] = 2.0
                self.template[i, 0, 2, 1] = 1.0
            self.template = nn.Parameter(data=self.template, requires_grad=False)

        elif self.conv_edge == 'conv1-laplacian':
            conv0 = torch.nn.Conv2d(self.in_channels, self.out_channels, kernel_size=1, padding=0)
            self.k0 = conv0.weight
            self.b0 = conv0.bias
            # init scale & bias
            scale = torch.randn(size=(self.out_channels, 1, 1, 1)) * 1e-3
            self.scale = nn.Parameter(torch.FloatTensor(scale))
            bias = torch.randn(self.out_channels) * 1e-3
            bias = torch.reshape(torch.FloatTensor(bias), (self.out_channels,))
            self.bias = nn.Parameter(bias)
            # init template
            self.template = torch.zeros((self.out_channels, 1, 3, 3), dtype=torch.float32)
            for i in range(self.out_channels):
                self.template[i, 0, 0, 1] = 1.0
                self.template[i, 0, 1, 0] = 1.0
                self.template[i, 0, 1, 2] = 1.0
                self.template[i, 0, 2, 1] = 1.0
                self.template[i, 0, 1, 1] = -4.0
            self.template = nn.Parameter(data=self.template, requires_grad=False)
        else:
            raise ValueError('the type of seqconv is not supported!')

    # 这段代码是一个模型的前向传播函数，用于对输入数据x进行卷积操作，并在填充边缘和卷积参数设置上进行了处理。
    def forward(self, x):
        # 这行代码使用了PyTorch的卷积函数F.conv2d()，对输入x进行卷积操作。
        # input 输入数据，即x。
        # weight 卷积核的权重，即self.k0
        # bias 卷积操作的偏置项，即self.b0
        # stride 卷积的步长
        y0 = F.conv2d(input=x, weight=self.k0, bias=self.b0, stride=1)
        # 这行代码使用PyTorch的填充函数F.pad()，对卷积结果y0进行边缘填充操作，增加边缘的宽度和高度各为1。填充方式为常数填充，填充值为0。
        y0 = F.pad(y0, (1, 1, 1, 1), 'constant', 0)
        # 这行代码对偏置项Self.b0进行形状变换，变换为大小为(1, out_channels, 1, 1)的张量。这样做是为了方便后续对填充的边缘区域进行赋值操作。
        b0_pad = self.b0.view(1, -1, 1, 1)
        # 这四行代码对填充后的边缘区域进行赋值，将填充区域的值设置为偏置项self.b0。通过这种方式可以保证边缘区域在后续的卷积操作中不会被影响。
        y0[:, :, 0:1, :] = b0_pad
        y0[:, :, -1:, :] = b0_pad
        y0[:, :, :, 0:1] = b0_pad
        y0[:, :, :, -1:] = b0_pad

        # 对填充后的结果y0进行第二次卷积操作
        # input 输入数据，weight 卷积核的而权重，self.scale 之前初始化的缩放因子，self.template 之前初始化的模板，bias 卷积操作的偏置项，stride 卷积的步长，groups 将输入和输出通道分成多个组，每个组之间的卷积操作独立进行
        y1 = F.conv2d(input=y0, weight=self.scale * self.template, bias=self.bias, stride=1, groups=self.out_channels)

        # 返回结果y1
        return y1

# 初始化模型的参数，该函数的作用是对输入的一个或多个网络模型中的卷积层、全连接层和批归一化层的参数进行初始化。
# 它使用了Kaiming正态分布初始化方法对权重进行初始化，并对需要的模块的偏置项进行清零操作。这些初始化操作可以帮助模型在训练开始时更好地拟合数据。
def initialize_weights(net_l, scale=1.0):
    # 首先判断net_l是否为列表类型，如果不是，则将其转化为只包含一个元素地列表。这样做是为了确保net_l是一个列表，方便后续对其中地网络模型进行处理。
    if not isinstance(net_l, list):
        net_l = [net_l]
    # 这两行代码使用嵌套地循环，第一个循环遍历net_l中的每个网络模型，第二循环遍历当前网络模型中的所有模块。
    for net in net_l:
        for m in net.modules():
            # 这段代码判断当前模块m是否是nn.Conv2d类型（卷积层）。如果是，则通过init.kaiming_normal_()初始化卷积层的权重，采用Kaiming正态分布初始化方法。然后根据指定的缩放因子scale对权重进行缩放，并清零偏置项的数据。
            if isinstance(m, nn.Conv2d):
                init.kaiming_normal_(m.weight, a=0, mode='fan_in')
                m.weight.data *= scale  # for residual block
                if m.bias is not None:
                    m.bias.data.zero_()
            # 这段代码判断当前模块m是否是nn.Linear类型（全连接层）。如果是，则同样使用Kaiming正态分布初始化方法对权重进行初始化，并根据缩放因子scale进行缩放。然后清零偏置项的数据。
            elif isinstance(m, nn.Linear):
                init.kaiming_normal_(m.weight, a=0, mode='fan_in')
                m.weight.data *= scale
                if m.bias is not None:
                    m.bias.data.zero_()
            # 判断当前模块m是否是nn.BatchNorm2d类型（批归一化层）。如果是，则将归一化层的权重设为常数值1，将偏置项设为常数值0.
            elif isinstance(m, nn.BatchNorm2d):
                init.constant_(m.weight, 1)
                init.constant_(m.bias.data, 0.0)


def make_layer(block, n_layers):
    layers = []
    for _ in range(n_layers):
        layers.append(block())
    return nn.Sequential(*layers)

# 该类定义了一个无批归一化(No BN)的残差块(Residual Block)，下面对每一句代码进行解释
# 这是一个继承自nn.Module的类定义，用于构建无批归一化的残差块。残差块的结构：卷积-激活函数-卷积-相加。
class ResidualBlock_noBN(nn.Module):

     # 残差块的初始化方法，
     # nf 表示滤波器数量或通道数的参数，默认为64。
     # at 是指定激活函数的参数，默认为'prelu'。
    def __init__(self, nf=64, at='relu'):
        # 首先调用父类的初始化方法super()
        super(ResidualBlock_noBN, self).__init__()
        # 然后创建两个卷积层self.conv1和self.conv2，其中输入和输出通道数均为nf，卷积核大小为3*3，步长为1，填充为1。
        self.conv1 = nn.Conv2d(nf, nf, 3, 1, 1, bias=True)
        self.conv2 = nn.Conv2d(nf, nf, 3, 1, 1, bias=True)
        # 这两个卷积层之间使用了激活函数self.act，通过调用action_function()方法创建
        self.act = action_function(nf, at)

        # 调用了一个名为initialize_weights()的函数，对self.conv1和self.conv2的权重进行初始化，初始值为0.1
        initialize_weights([self.conv1, self.conv2], 0.1)

    # 残差块的前向传播方法
    def forward(self, x):
        # 首先将输入x赋值给变量identity，这是为了在后续计算中将其与卷积结果相加，实现残差连接。
        identity = x
        # 然后将输入经过第一个卷积层你和激活函数self.act,得到out。
        out = self.act(self.conv1(x))
        # 接着将out经过第二个卷积层
        out = self.conv2(out)
        # 最后将identity和out相加得到输出。这样的设计可以让网络学习残差信息，从而更好的保留并传递输入的有效特征。
        return identity + out

# 创建不同类型的激活函数
# 定义了一个名为action_function的方法，接受两个参数n_feat和act_type，分别表示输入特征的通道数和激活函数的类型。
def action_function(n_feat, act_type):

    if act_type == 'prelu':
        # 创建一个带可学习参数的PReLU激活函数act，其中num_parameters参数设为n_feat，这样每个输入通道都有一个对应的可学习参数。
        act = nn.PReLU(num_parameters=n_feat)

    elif act_type == 'relu':
        # 创建一个ReLU激活函数act，其中inplace=True表示原地操作，即将计算结果直接替换输入、可以减少内存占用
        act = nn.ReLU(inplace=True)
    elif act_type == 'rrelu':
        # 创建一个随机修正线性单元(RReLU)激活函数act，其中lower和upper分别表示负半区间和正半区间的上下界，使用随机值进行修正。
        act = nn.RReLU(lower=-0.05, upper=0.05)
    elif act_type == 'lrelu':
        # 创建一个带负斜率的LeakyReLU激活函数act，其中negative_slope参数设为0.1，表示负半区间的斜率
        act = nn.LeakyReLU(negative_slope=0.1, inplace=True)
    elif act_type == 'softplus':
        # 创建一个softplus激活函数act
        act = nn.Softplus()
    elif act_type == 'linear':
        # 当参数为linear时，不进行任何操作。
        pass
    else:
        # 如果激活函数类型不被支持，则抛出值错误异常
        raise ValueError('The type of activation if not support!')
    # 返回创建的激活函数act
    return act
