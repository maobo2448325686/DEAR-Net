import torch
import torch.nn as nn
import torch.nn.functional as F


class cdloss(nn.Module):
    def __init__(self, gamma=1.5, size_average=True):
        super(cdloss, self).__init__()
        self.gamma = gamma
        self.size_average = size_average

    def forward(self, logit, target):
        target = target.view(-1)  # Flatten the target tensor
        logit = logit.view(-1)  # Flatten the logit tensor
        prob = torch.sigmoid(logit)  # Apply sigmoid to get probabilities
        prob_p = prob
        prob_n = 1.0 - prob
        batch_loss = - torch.pow((2 - prob_p), self.gamma) * torch.log(prob_p) * target \
                     - torch.log(prob_n) * (1 - target) * (2 - prob_n)
        if self.size_average:
            loss = batch_loss.mean()
        else:
            loss = batch_loss.sum()  # If not size_average, sum up the losses
        return loss
