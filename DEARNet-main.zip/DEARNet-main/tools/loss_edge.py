# # -*- coding: UTF-8 -*-
# """
# @file    : loss_edge.py
# @time    : 2023/11/7 0007 21:13
# @IDE     : Pycharm
# @Python  : 3.11.3
# @author  : KENOPSIAN
# """
#

#
# class CharbonnierLoss(nn.Module):
#     def __init__(self, epsilon=1e-6):
#         super(CharbonnierLoss, self).__init__()
#         self.epsilon = epsilon
#
#     def forward(self, input, target):
#         diff = input - target
#         loss = torch.sqrt(diff * diff + self.epsilon * self.epsilon)
#         return torch.mean(loss)
#
# class EdgeLoss(nn.Module):
#     def __init__(self, dist_edges, labels_edges):
#         super(EdgeLoss, self).__init__()
#         self.dist_edges = dist_edges
#         self.labels_edges = labels_edges
#         self.criterion = CharbonnierLoss()  # 使用Charbonnier损失函数
#
#     def forward(self):
#         edge_loss = self.criterion(self.dist_edges, self.labels_edges)  # 边缘损失函数
#         return edge_loss
