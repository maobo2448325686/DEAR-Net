import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
import torch.optim as optim
# import torchvision
from data_loader_new import Dataset_self
from data_utils import calMetric_iou
import numpy as np
from model.DEARNet import DEARNet
from tools.eval import Statistics, Calculation
import itertools
from tqdm import tqdm
import cv2
import os

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def img(prob, filename):
    prob = np.squeeze(prob)
    prob = (prob * 255).astype(np.uint8)
    save_dir = r"D:\software\Data\Pycharm\DEARNet\result\whu\res_test"
    save_path = os.path.join(save_dir, f'{filename}.png')
    _, binary_image = cv2.threshold(prob, 127, 255, cv2.THRESH_BINARY)
    cv2.imwrite(save_path, binary_image)


def test(input_a, modelfile, network_name, BATCH_SIZE=1):
    data_loader_test_img = torch.utils.data.DataLoader(dataset=input_a,
                                                       batch_size=1, shuffle=True)

    model = network_name()

    model.load_state_dict(torch.load(modelfile)['model'])
    if torch.cuda.is_available():
        model = model.cuda()
    i_count = 1
    matrix_all = np.array([0, 0, 0, 0])

    model.eval()
    test_bar = tqdm(data_loader_test_img)
    inter, unin = 0, 0
    matrix_all = np.array([0, 0, 0, 0])
    valing_results = {'loss': 0, 'SR_loss': 0, 'CD_loss': 0, 'batch_sizes': 0, 'IoU': 0}
    for img1, img2, labels, filename in test_bar:
        valing_results['batch_sizes'] += 1

        data1 = img1.to(device, dtype=torch.float)
        data2 = img2.to(device, dtype=torch.float)
        labels = labels.to(device, dtype=torch.float)
        labels = torch.argmax(labels, 1).unsqueeze(1).float()

        gt_value = labels.float()
        dist = model(data1, data2)

        prob = (dist > 0.5).float()
        prob = prob.cpu().detach().numpy()
        # img(prob, filename)

        gt_value = gt_value.cpu().detach().numpy()
        gt_value = np.squeeze(gt_value)
        result = np.squeeze(prob)
        intr, unn = calMetric_iou(gt_value, result)
        inter = inter + intr
        unin = unin + unn

        # loss for current batch before optimization
        valing_results['IoU'] = (inter * 1.0 / unin)

        test_bar.set_description(
            desc='IoU: %.4f' % (valing_results['IoU'],
                                ))

        ### evaluation
        matrix = Statistics(gt_value, result)
        matrix_all = matrix + matrix_all

    acc, recall, precision, f1, K = Calculation(matrix_all)
    print("OA:", acc, "P值:", precision, "R值:", recall, "F1值:", f1, "kappa值:", K)


if __name__ == '__main__':
    ############### training data path and model dir
    data_A_dir = r'D:\software\Data\Pycharm\DEARNet-main\data\Lebedev'
    data_test_dir = data_A_dir + r'\test\images'
    network_name = DEARNet
    batch_size = 4

    ### test levir_CD
    for i in range(10, 101):
        modelfile = './result/lebedev/所有模型/PVT-' + str(i) + '_model.pkl'
        input_test = Dataset_self(data_test_dir)
        test(input_test, modelfile, network_name, BATCH_SIZE=4)
