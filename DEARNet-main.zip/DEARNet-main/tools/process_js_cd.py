import os
import random
import shutil

# 按需分配
source_folder = r'D:\DataSoftWare\maobo\Pycharm\GAS-Net-main-new\data\WHU_CD\change label\label'  # 源文件夹路径
reference_folder = r'D:\DataSoftWare\maobo\Pycharm\GAS-Net-main-new\data\WHU_CD\val\images\t1'  # 参考文件夹路径
output_folder = r'D:\DataSoftWare\maobo\Pycharm\GAS-Net-main-new\data\WHU_CD\val\label'  # 输出文件夹路径

# 获取参考文件夹中的所有图片文件名
reference_files = [os.path.splitext(file)[0] for file in os.listdir(reference_folder) if file.endswith(".png")]

# 遍历源文件夹中的所有文件
for file in os.listdir(source_folder):
    if file.endswith(".png"):
        filename = os.path.splitext(file)[0]
        if filename in reference_files:
            # 如果文件名在参考文件夹中存在，则移动文件到输出文件夹
            source_file_path = os.path.join(source_folder, file)
            output_file_path = os.path.join(output_folder, file)
            shutil.move(source_file_path, output_file_path)