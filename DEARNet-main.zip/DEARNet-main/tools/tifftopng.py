from PIL import Image
Image.MAX_IMAGE_PIXELS = None
input_file = r'D:\DataSoftWare\maobo\Pycharm\GAS-Net-main-new\data\WHU_CD\change label\change_label.tif'  # 输入文件路径
output_file = r'D:\DataSoftWare\maobo\Pycharm\GAS-Net-main-new\data\WHU_CD\before\change_label.png'  # 输出文件路径

# 打开TIFF图像
image = Image.open(input_file)

# 转换为PNG格式并保存
image.save(output_file, "PNG", compression=None)
