# import cv2
# import numpy as np
# import torch
# import torch.nn as nn
# import torch
# import matplotlib.pyplot as plt
#
# def getEdgeMap(predicted_labels, labels_base, filenames, dist):
#
#     save_path_dist = './data/SVCD/result/'
#     save_path_lab = './data/SVCD/edge/lab/'
#     save_path_pre = './data/SVCD/edge/pre/'
#
#     labels_base_tensor = labels_base.unsqueeze(1).float().cuda()
#     predicted_labels_tensor = predicted_labels.unsqueeze(1).float().cuda()
#
#     # Laplacian算子
#     laplacian_operator = torch.tensor([[0, 1, 0], [1, -4, 1], [0, 1, 0]], dtype=torch.float32).unsqueeze(0).unsqueeze(
#         0).cuda()
#
#     batch_size = labels_base_tensor.size(0)
#
#     edges_loss = 0
#
#     edges_labels_base = torch.empty_like(labels_base_tensor)
#     edges_predicted_labels = torch.empty_like(predicted_labels_tensor)
#
#     for i in range(batch_size):
#         edges_labels_base[i] = torch.nn.functional.conv2d(labels_base_tensor[i], laplacian_operator, padding=1)
#         edges_predicted_labels[i] = torch.nn.functional.conv2d(predicted_labels_tensor[i], laplacian_operator, padding=1)
#
#         # 以下注释代码为可视化
#         pro1 = (edges_labels_base[i] > 0.5).float()
#         pro1 = pro1.cpu().detach().numpy()
#         result1 = np.squeeze(pro1)
#
#         pro2 = (edges_predicted_labels[i] > 0.5).float()
#         pro2 = pro2.cpu().detach().numpy()
#         result2 = np.squeeze(pro2)
#
#         pro_dist = (dist[i] > 0.5).float()
#         pro_dist = pro_dist.cpu().detach().numpy()
#         result_dist = np.squeeze(pro_dist)
#
#
#         # 将预测结果转换为0或1的标签
#         pro1_lab = (result1 > 0.5).astype(int)
#         # 将1转换为255，以匹配标签图片的颜色表示
#         pro1_lab = pro1_lab * 255
#
#         # 将预测结果转换为0或1的标签
#         pro2_pre = (result2 > 0.5).astype(int)
#         # 将1转换为255，以匹配标签图片的颜色表示
#         pro2_pre = pro2_pre * 255
#
#         # 将预测结果转换为0或1的标签
#         pro3_dist = (result_dist > 0.5).astype(int)
#         # 将1转换为255，以匹配标签图片的颜色表示
#         pro3_dist = pro3_dist * 255
#
#         path_lab = filenames[i]
#         # print(filenames[i])
#         # 保存预测结果
#         cv2.imwrite(save_path_lab + path_lab, pro1_lab)
#         cv2.imwrite(save_path_pre + path_lab, pro2_pre)
#         cv2.imwrite(save_path_dist + path_lab, pro3_dist)
#
#         # 对边缘图像进行归一化处理（范围缩放到[0, 1]）
#         edges_labels_base = (edges_labels_base - edges_labels_base.min()) / (
#                 edges_labels_base.max() - edges_labels_base.min() + 1e-6)
#         edges_predicted_labels = (edges_predicted_labels - edges_predicted_labels.min()) / (
#                 edges_predicted_labels.max() - edges_predicted_labels.min() + 1e-6)
#
#         # 计算CharbonnierLoss损失函数
#         charbonnier_loss = torch.mean(torch.sqrt((edges_labels_base - edges_predicted_labels) ** 2 + 1e-6 * 1e-6))
#
#         edges_loss += charbonnier_loss
#
#         # 求平均边缘损失值
#     edges_loss /= batch_size
#
#     # 返回边缘损失值
#     return edges_loss
#
#
#
#
# class CharbonnierLoss(nn.Module):
#     def __init__(self, input, target, epsilon=1e-6):
#         super(CharbonnierLoss, self).__init__()
#         self.input = input
#         self.target = target
#         self.epsilon = epsilon
#
#     def forward(self):
#         diff = self.input - self.target
#         loss = torch.mean(torch.sqrt(diff * diff + self.epsilon * self.epsilon))
#         return loss



import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt

# 定义 Charbonnier 损失函数
class CharbonnierLoss(nn.Module):
    def __init__(self, epsilon=1e-6):
        super(CharbonnierLoss, self).__init__()
        self.epsilon = epsilon

    def forward(self, input, target):
        diff = input - target
        loss = torch.mean(torch.sqrt(diff * diff + self.epsilon * self.epsilon))
        return loss

def getEdgeMap(predicted_labels, labels_base, filenames, dist):
    save_path_dist = './data/SVCD/result/'
    save_path_lab = './data/SVCD/edge/lab/'
    save_path_pre = './data/SVCD/edge/pre/'

    labels_base_tensor = labels_base.unsqueeze(1).float().cuda()
    predicted_labels_tensor = predicted_labels.unsqueeze(1).float().cuda()

    # Laplacian算子
    laplacian_operator = torch.tensor([[0, 1, 0], [1, -4, 1], [0, 1, 0]], dtype=torch.float32).unsqueeze(0).unsqueeze(
        0).cuda()

    batch_size = labels_base_tensor.size(0)

    epsilon = 1e-6
    # edges_loss = 0
    edges_loss = torch.zeros(1, requires_grad=True).cuda()

    edges_labels_base = torch.empty_like(labels_base_tensor)
    edges_predicted_labels = torch.empty_like(predicted_labels_tensor)

    for i in range(batch_size):

        edges_labels_base[i] = torch.nn.functional.conv2d(labels_base_tensor[i], laplacian_operator, padding=1)
        edges_predicted_labels[i] = torch.nn.functional.conv2d(predicted_labels_tensor[i], laplacian_operator,
                                                               padding=1)

        # # 以下注释代码为可视化
        # pro1 = (edges_labels_base[i] > 0.5).float()
        # pro1 = pro1.cpu().detach().numpy()
        # result1 = np.squeeze(pro1)
        #
        # pro2 = (edges_predicted_labels[i] > 0.5).float()
        # pro2 = pro2.cpu().detach().numpy()
        # result2 = np.squeeze(pro2)
        #
        # pro_dist = (dist[i] > 0.5).float()
        # pro_dist = pro_dist.cpu().detach().numpy()
        # result_dist = np.squeeze(pro_dist)
        #
        # # 将预测结果转换为0或1的标签
        # pro1_lab = (result1 > 0.5).astype(int)
        # # 将1转换为255，以匹配标签图片的颜色表示
        # pro1_lab = pro1_lab * 255
        #
        # # 将预测结果转换为0或1的标签
        # pro2_pre = (result2 > 0.5).astype(int)
        # # 将1转换为255，以匹配标签图片的颜色表示
        # pro2_pre = pro2_pre * 255
        #
        # # 将预测结果转换为0或1的标签
        # pro3_dist = (result_dist > 0.5).astype(int)
        # # 将1转换为255，以匹配标签图片的颜色表示
        # pro3_dist = pro3_dist * 255
        #
        # path_lab = filenames[i]
        # # print(filenames[i])
        # # 保存预测结果
        # cv2.imwrite(save_path_lab + path_lab, pro1_lab)
        # cv2.imwrite(save_path_pre + path_lab, pro2_pre)
        # cv2.imwrite(save_path_dist + path_lab, pro3_dist)

        # 对边缘图像进行归一化处理（范围缩放到[0, 1]）
        edges_labels_base = (edges_labels_base - edges_labels_base.min()) / (
                edges_labels_base.max() - edges_labels_base.min() + 1e-6)
        edges_predicted_labels = (edges_predicted_labels - edges_predicted_labels.min()) / (
                edges_predicted_labels.max() - edges_predicted_labels.min() + 1e-6)

        # charbonnier_loss = CharbonnierLoss(edges_predicted_labels[i], edges_labels_base[i])
        charbonnier_loss = CharbonnierLoss().cuda()
        loss = charbonnier_loss(edges_predicted_labels[i], edges_labels_base[i])
        # edge_loss = torch.mean(torch.sqrt((edges_predicted_labels[i] - edges_labels_base[i]) * (edges_predicted_labels[i] - edges_labels_base[i]) + epsilon * epsilon))

        edges_loss = edges_loss + loss

    edges_loss /= batch_size

    # edges_loss.backward()  # 计算梯度

    # 返回边缘损失值
    return edges_loss

